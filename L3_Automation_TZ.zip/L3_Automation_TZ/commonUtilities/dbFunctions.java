package commonUtilities;

public class dbFunctions {

}
