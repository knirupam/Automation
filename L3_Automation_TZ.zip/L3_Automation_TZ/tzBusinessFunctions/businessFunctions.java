package tzBusinessFunctions;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import commonUtilities.excelFunctions;
import commonUtilities.globalVar;
import commonUtilities.orFunctions;

public class businessFunctions {
	
	public static excelFunctions iXL;
	public static excelFunctions oXL;
	public static orFunctions OR;
	
	public static void loadPropertyFiles() throws Exception {
		String strPropertiesFilePath = globalVar.tzObjectRepoFolder+"TZ_Home.properties";
		strPropertiesFilePath = strPropertiesFilePath +";"+ globalVar.tzObjectRepoFolder+"TZ_Login.properties";
		strPropertiesFilePath = strPropertiesFilePath +";"+ globalVar.tzObjectRepoFolder+"TZ_TestScratch.properties";
		strPropertiesFilePath = strPropertiesFilePath +";"+ globalVar.tzObjectRepoFolder+"TZ_TestScratchDoc.properties";
		strPropertiesFilePath = strPropertiesFilePath +";"+ globalVar.tzObjectRepoFolder+"TZ_NewArticle.properties";
		strPropertiesFilePath = strPropertiesFilePath +";"+ globalVar.tzObjectRepoFolder+"TZ_TestScratchSearchResult.properties";
		strPropertiesFilePath = strPropertiesFilePath +";"+ globalVar.tzObjectRepoFolder+"TZ_KnowledgeBase.properties";
		strPropertiesFilePath = strPropertiesFilePath +";"+ globalVar.tzObjectRepoFolder+"TZ_ScratchBoard.properties";
		strPropertiesFilePath = strPropertiesFilePath +";"+ globalVar.tzObjectRepoFolder+"TZ_NewDiscussion.properties";
		strPropertiesFilePath = strPropertiesFilePath +";"+ globalVar.tzObjectRepoFolder+"TZ_UserProfile.properties";
		OR = new orFunctions(strPropertiesFilePath);	
	}
	
	public static Map<String, String> readInputRow(int iRow) throws IOException {
		iXL = new excelFunctions(commonUtilities.globalVar.tzFilePath, "Sheet1");
		String cols = iXL.excelGetColumnNames();
		String[] colNames = cols.split(";");
		Map<String, String> InputData = new HashMap<String, String>();
		for(int i=0;i<colNames.length-1;i++) {
			InputData.put(colNames[i+1], iXL.excelReadCell(iRow, i));
		}
		return InputData;
	}
		
	public static void createORforPage(String pageName) throws Exception {
		OR.object_map.clear();
		switch(pageName) {
		case "login" : OR.createWebElement(2);
		break;
		case "home" : OR.createWebElement(1);
		break;
		case "test scratch" : OR.createWebElement(3);
		break;
		case "test scratch doc" : OR.createWebElement(4);
		break;
		case "test scratch search result" : OR.createWebElement(6);
		break;
		case "new article" : OR.createWebElement(5);
		break;
		case "knowledge base" : OR.createWebElement(7);
		break;
		case "scratch board" : OR.createWebElement(8);
		break;
		case "new discussion" : OR.createWebElement(9);
		break;
		case "user profile" : OR.createWebElement(10);
		break;
		}		
	}
	
	public static void compareStringAndWriteResult(String strExpected, String strActual, String strLog, int iRow, boolean screenshot) throws IOException {
		String[] resultlog = strLog.split("-");
		oXL = new excelFunctions(globalVar.tzResultPath, "Sheet1");
		oXL.excelWriteCell(iRow, 0, resultlog[0], false);
		oXL.excelWriteCell(iRow, 1, resultlog[1], false);
		oXL.excelWriteCell(iRow, 2, strExpected, false);
		oXL.excelWriteCell(iRow, 3, strActual, false);
		if(screenshot) {
			String path = OR.captureScreen(globalVar.tzResultSCfolder);
			oXL.excelWriteCell(iRow, 5, path, true);
			String spath = "<img src=\"file://" + path + "\" alt=\"\"/>";
			Reporter.log(spath);
		}		
		if (strExpected.equals(strActual)){
			oXL.excelWriteCell(iRow, 4, "Pass", false);
		}else oXL.excelWriteCell(iRow, 4, "Fail", false);		
	}
	
	public static String LoginTZ(String browser, String url, String userId,String password){
		try {
			orFunctions.launchWithoutPingID(browser, url, userId, password);
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_Home.properties");
			createORforPage("home");
			if(OR.object_map.get("oLbl_Home").get(0)==null) {
				return "Unable to Login";
			}	
		}catch (Exception e) {
			Reporter.log("<img src=\"file://" + OR.captureScreen(globalVar.tzResultSCfolder) + "\" alt=\"\"/>");
		} return "Successful Login";
	}
	
	public static String NavigateToPage(String LinkToClick, String ORName) throws Exception{
		//try {
			OR.object_map.get(LinkToClick).get(0).click();	
			Thread.sleep(5000);
			if(!(ORName.equals(""))){
			//if(index>-1) {
				createORforPage(ORName);
				//createORforPage(index);
			}
			if(OR.object_map.get("oLbl_Breadcrumb")!=null) {
				return OR.object_map.get("oLbl_Breadcrumb").get(0).getText().toString();				
			}
		/*} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("<img src=\"file://" + OR.captureScreen(globalVar.tzResultSCfolder) + "\" alt=\"\"/>");
		}*/ return null;
	}
	
	public static void selectFromAutoComplete(String ObjectName, String Keyword) throws InterruptedException {
		OR.object_map.get("oEdt_labels").get(0).click();
		OR.object_map.get(ObjectName).get(0).sendKeys(Keyword);
		Thread.sleep(2000);
		Actions action = new Actions(orFunctions.driver);
		action.sendKeys(Keys.DOWN);
		action.sendKeys(Keys.UP);
		action.sendKeys(Keys.ENTER);
		action.perform();	
	}
	
	public static String CreateArticle(String Template, String Language, String Subject, String Text) throws Exception{
		String strBreadcrumb;
		//try {
			//if(OR==null) {
				//createORforPage(globalVar.tzObjectRepoFolder+"TZ_Home.properties");
				createORforPage("home");
			//}
			//businessFunctions.NavigateToPage("oLnk_ScratchWork","");
			businessFunctions.NavigateToPage("oLnk_ScratchWork","");
			//strBreadcrumb = businessFunctions.NavigateToPage("oLnk_TestScratch",globalVar.tzObjectRepoFolder+"TZ_TestScratch.properties");
			strBreadcrumb = businessFunctions.NavigateToPage("oLnk_TestScratch","test scratch");
			if((strBreadcrumb==null)||(!(strBreadcrumb.equals("Test Scratch")))) {
				return "Test Scratch page did not open";
			}			
			//strBreadcrumb = businessFunctions.NavigateToPage("oLnk_NewArticle",globalVar.tzObjectRepoFolder+"TZ_NewArticle.properties");
			strBreadcrumb = businessFunctions.NavigateToPage("oLnk_NewArticle","new article");
			if((strBreadcrumb==null)||(!(strBreadcrumb.equals("New Article")))){
				return "New Article page did not open";
			}
			OR.object_map.get("oEdt_Subject").get(0).click();
			OR.object_map.get("oEdt_ArticleText").get(0).click();
			int NumTempaltes = OR.object_map.get("oRdBtn_TemplateGrp").size();
			for(int i=0;i<NumTempaltes;i++) {					
				if(OR.object_map.get("oLbl_TemplateRdGrp").get(i).getText().equals(Template)) {
					OR.object_map.get("oRdBtn_TemplateGrp").get(i).click();
					orFunctions.handleAlert("warning");		
					break;
				}
			}
			if(!(Language.equals(""))) {
				Select oSel_Language = new Select(OR.object_map.get("oSel_Language").get(0));
				oSel_Language.selectByValue(Language);
				if(!(ExpectedConditions.alertIsPresent()==null)) {
					orFunctions.handleAlert("warning");		
				}
			}
			OR.object_map.get("oEdt_Subject").get(0).sendKeys(Subject);
			OR.object_map.get("oEdt_ArticleText").get(0).click();	
			OR.object_map.get("oEdt_Subject").get(0).click();
			//OR.object_map.get("oEdt_ArticleText").get(0).sendKeys("testing 123");
			orFunctions.switchToIframe("tinymceeditor_ifr");
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_NewArticle.properties");
			createORforPage("new article");
			OR.object_map.get("oEdt_TextEditorFrame").get(0).sendKeys("testing 456");
			orFunctions.driver.switchTo().defaultContent();		
			Thread.sleep(2000);
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_NewArticle.properties");
			createORforPage("new article");
			OR.object_map.get("oBtn_InsertPic").get(0).click();			
			//orFunctions.handleAlert("image");
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_NewArticle.properties");
			createORforPage("new article");
			OR.object_map.get("oBtn_ImageURL").get(0).click();
			//Thread.sleep(2000);
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_NewArticle.properties");
			createORforPage("new article");
			OR.object_map.get("oEdt_ImageURL").get(0).sendKeys(globalVar.tzTestImageURL);
			//orFunctions.driver.findElement(By.xpath("//input[@class='lia-media-image-url-upload-input lia-form-type-text lia-form-input-vertical ng-pristine ng-valid ng-touched']")).sendKeys(globalVar.tzTestImageURL);
			Thread.sleep(2000);
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_NewArticle.properties");
			createORforPage("new article");
			OR.object_map.get("oBtn_Done").get(0).click();			
			orFunctions.driver.switchTo().defaultContent();		
			Thread.sleep(2000);
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_NewArticle.properties");
			createORforPage("new article");
			orFunctions.switchToIframe(OR.object_map.get("oFrm_Video").get(0));
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_NewArticle.properties");
			createORforPage("new article");
			OR.object_map.get("oLnk_WebVideoTab").get(0).click();	
			OR.object_map.get("oEdt_VideoURL").get(0).sendKeys(globalVar.tzTestVideoURL);
			OR.object_map.get("oBtn_Preview").get(0).click();	
			Thread.sleep(2000);
			OR.object_map.get("oBtn_InsertVideo").get(0).click();	
			Thread.sleep(2000);
			orFunctions.driver.switchTo().defaultContent();		
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_NewArticle.properties");
			createORforPage("new article");
			businessFunctions.selectFromAutoComplete("oEdt_labels","Administration");
			businessFunctions.selectFromAutoComplete("oEdt_labels","10GE-XP");
			businessFunctions.selectFromAutoComplete("oEdt_labels","Create Script");
			businessFunctions.selectFromAutoComplete("oEdt_labels","CCO Category");								
			switch (Template){
				case "Troubleshooting Tech Note":
					businessFunctions.selectFromAutoComplete("oEdt_labels","Troubleshooting Guide");
				break;
				case "Configuration Example":
					businessFunctions.selectFromAutoComplete("oEdt_labels","Configuration Guide");
				break;
				case "Question and Answer":
					businessFunctions.selectFromAutoComplete("oEdt_labels","Q&A");
				break;
				case "Problem/Solution":
					businessFunctions.selectFromAutoComplete("oEdt_labels","Problem");
					businessFunctions.selectFromAutoComplete("oEdt_labels","Solution");
				break;
			}			
			OR.object_map.get("oBtn_SaveReview").get(0).click();		
			Thread.sleep(2000);
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_KnowledgeBase.properties");
			createORforPage("knowledge base");
			strBreadcrumb = OR.object_map.get("oLbl_Breadcrumb").get(0).getText().toString();
			if(strBreadcrumb.equals("Knowledge Base Article Dashboard")) {
				return OR.object_map.get("oLbl_DocSavedMsg").get(0).getText().toString().split("!")[0];
			}
		//} catch(Exception e) {
		//	Reporter.log("<img src=\"file://" + OR.captureScreen(globalVar.tzResultSCfolder) + "\" alt=\"\"/>");
		//}
		return "Document not saved";
	}
	
	public static String SearchArticleInKnowledgeBase(String ArticleName){
		String strBreadcrumb;		
		try {
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_Home.properties");
			createORforPage("home");;;
			//businessFunctions.NavigateToPage("oLnk_ScratchWork","");
			businessFunctions.NavigateToPage("oLnk_ScratchWork","");
			//strBreadcrumb = businessFunctions.NavigateToPage("oLnk_TestScratch",globalVar.tzObjectRepoFolder+"TZ_TestScratch.properties");
			strBreadcrumb = businessFunctions.NavigateToPage("oLnk_TestScratch","test scratch");
			if((strBreadcrumb==null)||(!(strBreadcrumb.equals("Test Scratch")))) {
				return "Test Scratch page did not open";
			}	
			OR.object_map.get("oEdt_Search").get(0).sendKeys(ArticleName);
			OR.object_map.get("oBtn_Search").get(0).click();
			Thread.sleep(2000);
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_TestScratchSearchResult.properties");
			createORforPage("test scratch search result");
			if(OR.object_map.get("oLbl_SearchResult").get(0).getText().equals(ArticleName)) {
				OR.object_map.get("oLnk_SearchResult").get(0).click();
			}
			Thread.sleep(2000);		
			//createORforPage(globalVar.tzObjectRepoFolder+"TZ_TestScratchDoc.properties");
			createORforPage("test scratch doc");
			if(OR.object_map.get("oLbl_Breadcrumb").get(0).getText().toString().equals(ArticleName)) {
				return "Article found";
			}
		} catch (Exception e) {
			Reporter.log("<img src=\"file://" + OR.captureScreen(globalVar.tzResultSCfolder) + "\" alt=\"\"/>");
		}
		return "Article not found";
	}
	
	public static void Logout() {
		orFunctions.logout();
	}
	
	public static String valBoards(){
		String Actual="Displayed:-";
		try {
			//businessFunctions.NavigateToPage("oLnk_ScratchWork","");
			NavigateToPage("oLnk_ScratchWork","");
			if(OR.object_map.get("oLnk_ScratchDBoard").get(0).isDisplayed()) Actual=Actual+"ScratchBoard";
			Actual=Actual+":"+OR.object_map.get("oLbl_IconScratchDBoard").get(0).getAttribute("title");
			if(OR.object_map.get("oLnk_TestScratch").get(0).isDisplayed()) Actual=Actual+";TestScratch";
			Actual=Actual+":"+OR.object_map.get("oLbl_IconTestScratch").get(0).getAttribute("title");
			if(OR.object_map.get("oLnk_ScratchIdea").get(0).isDisplayed()) Actual=Actual+";ScratchIdea";
			Actual=Actual+":"+OR.object_map.get("oLbl_IconScratchIdea").get(0).getAttribute("title");
			if(OR.object_map.get("oLnk_TestBlog").get(0).isDisplayed()) Actual=Actual+";TestBlog";
			Actual=Actual+":"+OR.object_map.get("oLbl_IconTestBlog").get(0).getAttribute("title");
			//compareStrings("Icon for Scratch Discussion Board","forum",OR.object_map.get("oLbl_IconScratchDBoard").get(0).getAttribute("title"));
			//compareStrings("Icon for Scratch Idea","idea exchange",OR.object_map.get("oLbl_IconScratchIdea").get(0).getAttribute("title"));
			//compareStrings("Icon for Test Blog","blog",OR.object_map.get("oLbl_IconTestBlog").get(0).getAttribute("title"));
			//businessFunctions.NavigateToPage("oLnk_ScratchWork","");
			businessFunctions.NavigateToPage("oLnk_ScratchWork","");
		} catch (Exception e) {
			//Reporter.log(e.toString());
			Reporter.log("<img src=\"file://" + OR.captureScreen(globalVar.tzResultSCfolder) + "\" alt=\"\"/>");
		} return Actual;
	}
	
	public static void compareStrings(String log, String Expected, String Actual) throws Exception{
		Reporter.log(log+"::Expected:"+Expected+",Actual:"+Actual);	
		String Exp[] = Expected.split(";");
		String Act[] = Actual.split(";");
		for(int i=0; i<Exp.length; i++) {				
			Assert.assertEquals(Act[i].trim().toUpperCase(), Exp[i].trim().toUpperCase());
		}						
	}
	
	public static void createDiscussion(String Subject, String Message, String FilePath) throws Exception {
		businessFunctions.NavigateToPage("oLnk_ScratchWork","");
		businessFunctions.NavigateToPage("oLnk_ScratchDBoard","scratch board");
		businessFunctions.NavigateToPage("oLnk_NewMsg","new discussion");
		OR.object_map.get("oEdt_Subject").get(0).sendKeys(Subject);
		orFunctions.switchToIframe(OR.object_map.get("oFrm_TextEditor").get(0));
		createORforPage("new discussion");
		OR.object_map.get("oEdt_TextEditorFrame").get(0).sendKeys(Message);
		orFunctions.driver.switchTo().defaultContent();
		createORforPage("new discussion");
		OR.object_map.get("oEdt_Attach").get(0).sendKeys(FilePath);
		OR.object_map.get("oEdt_Subject").get(0).click();
		OR.object_map.get("oBtn_Post").get(0).click();
	}
	
	public static String valUserProfileWidgets() throws Exception {
		createORforPage("home");
		String Actual="";
		businessFunctions.NavigateToPage("oLnk_User","user profile");
		if(OR.object_map.get("oLbl_LatestPosts").get(0).isDisplayed()) Actual = "Latest Posts; ";
		if(OR.object_map.get("oLbl_AutosavedDrafts").get(0).isDisplayed()) Actual = Actual + "Autosaved Drafts; ";
		if(OR.object_map.get("oLbl_MyPhotos").get(0).isDisplayed()) Actual = Actual + "My Photos; ";
		if(OR.object_map.get("oLbl_MyVideos").get(0).isDisplayed()) Actual = Actual + "My Videos; ";
		if(OR.object_map.get("oLbl_MyTags").get(0).isDisplayed()) Actual = Actual + "My Tags; ";
		if(OR.object_map.get("oLbl_KudosGivenTo").get(0).isDisplayed()) Actual = Actual + "Kudos Given To; ";
		if(OR.object_map.get("oLbl_PublicStats").get(0).isDisplayed()) Actual = Actual + "Public Statistics; ";
		if(OR.object_map.get("oLbl_PrivateStats").get(0).isDisplayed()) Actual = Actual + "Private Statistics; ";
		if(OR.object_map.get("oLbl_PostsIKudoed").get(0).isDisplayed()) Actual = Actual + "Posts I Kudoes; ";
		if(OR.object_map.get("oLbl_MyKbc").get(0).isDisplayed()) Actual = Actual + "My Knowledge Base Contribution; ";
		if(OR.object_map.get("oLbl_MySubscription").get(0).isDisplayed()) Actual = Actual + "My Subscription; ";
		return Actual;
	}
	
	public static String valUserDetail() {
		String Actual = OR.object_map.get("oEdt_Tbl_UserName").get(0).getText() + "; ";
		Actual = Actual + OR.object_map.get("oEdt_Tbl_UserEmail").get(0).getText() + "; ";
		Actual = Actual + OR.object_map.get("oEdt_Tbl_UserLoc").get(0).getText();
		return Actual;
	}
	
	public static String valUserImage() {		
		return orFunctions.GetToolTipText(OR.object_map.get("oImg_User").get(0));
	}

}


























