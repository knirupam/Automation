package tzStage;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import commonUtilities.encryptionDecryption;
import commonUtilities.globalVar;
import tzBusinessFunctions.businessFunctions;

public class driverClass {

	public static Map<String, String> Input; //This map is used to fetch values from a row in driver sheet (Map<Column_Name:Value>) 
	SoftAssert softAssertion;
	String NewDocName;
	
	@Parameters({"browser","appURL"})
	@BeforeClass
	public void login(String browser, String appURL) throws Exception {
	//This method is to Login with correct User ID and password before executing test cases.		
		businessFunctions.loadPropertyFiles();
		Reporter.log("This method is to Login with correct User ID and password before starting execution of tests.");
		softAssertion= new SoftAssert();	
		Input = businessFunctions.readInputRow(1);
		String ActualMsg = businessFunctions.LoginTZ(browser, appURL, Input.get("UserId"), encryptionDecryption.decryptXOR(Input.get("EncodedPwd"),"1"));
		businessFunctions.compareStrings("Login Happy Path", Input.get("LoginMessage"), ActualMsg);
		//Assert.assertEquals(ActualMsg, Input.get("LoginMessage"), "Login Happy Path");
		//businessFunctions.compareStringAndWriteResult(Input.get("LoginMessage"),ActualMsg,"Login_HappyPath-Login Test",1,true);
	}
	
	@Test(priority=1)
	public void homePageValidatingBoards() {
	//TZ Homepage > verification of all the boards like, discussion, TKB and ideas		
		Reporter.log("This method is to validate that all icons are properly coming under Sratch Work Tree-view");
		String Expected = "Displayed:-ScratchBoard:Forum;TestScratch:Knowledge Base;ScratchIdea:Idea Exchange;TestBlog:Blog";
		String Actual = businessFunctions.valBoards();
		Assert.assertEquals(Actual, Expected, "Home Page - links present");
	}
	
	@Test(priority=1)
	public void createNewArticle() throws Exception {
	//This method is to test Creating New Scratch Document and saving it to drafts
		Reporter.log("This method is to test Creating New Scratch Document and saving it to drafts.");
		NewDocName = Input.get("ArticleName")+"_"+(new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date())).replace(".", "");
		String ActualMsg = businessFunctions.CreateArticle(Input.get("Template"),Input.get("Language"),NewDocName,"<p>"+Input.get("ArticleText")+"</p>");						
		softAssertion.assertEquals(ActualMsg, Input.get("ArticleCreateMessage"), "Create Scratch Document");
		//businessFunctions.compareStringAndWriteResult(Input.get("ArticleCreateMessage"), ActualMsg, "Create Scratch Doc-Creating Scratch Doc", 2, true);
		softAssertion.assertAll();
	}
	
	@Test(priority=2)
	public void searchArticle() throws Exception {
	//This method is to test Searching Scratch Document with name
		Reporter.log("This method is to test Searching Scratch Document with name");
		String ActualMsg = businessFunctions.SearchArticleInKnowledgeBase(NewDocName);
		softAssertion.assertEquals(ActualMsg, Input.get("ArticleSearchMessage"), "Search Article");
		businessFunctions.compareStringAndWriteResult(Input.get("ArticleSearchMessage"), ActualMsg, "Search Scratch Doc-Searching Scratch Doc", 3, true);
		softAssertion.assertAll();
	}
	
	@Test
	public void createDiscussionBoard() throws Exception {
		Reporter.log("This method is to test creating a new discussion in scratch discussion board");
		NewDocName = "NewDiscussion_"+(new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date())).replace(".", "");
		businessFunctions.createDiscussion(NewDocName, "testing "+NewDocName, "C:\\Selenium\\Eclipse_Workspace\\L3_Automation\\tzStage\\driverSheet.xlsx");
	}
	
	@Test
	public void validateUserProfile() throws Exception {
		String UserWidgets = businessFunctions.valUserProfileWidgets();
		String expUserWidgets = "Latest Posts; Autosaved Drafts; My Photos; My Videos; My Tags; Kudos Given To; Public Statistics; Private Statistics; Posts I Kudoes; My Knowledge Base Contribution; My Subscription";
		businessFunctions.compareStrings("Validating Widgets visible on User Profile", expUserWidgets, UserWidgets);
		String UserDetails = businessFunctions.valUserDetail();		
		String expUserDetails = "Kirti Nirupama; knirupam@cisco.com; Bangalore";
		businessFunctions.compareStrings("Validating User Deatils", expUserDetails, UserDetails);		
		String UserImgText = businessFunctions.valUserImage();
		String expUserImgText = "knirupam is a Specialist Level 1";
		businessFunctions.compareStrings("Validating Tooltip text on User Image", expUserImgText, UserImgText);
		businessFunctions.compareStringAndWriteResult(expUserImgText,UserImgText,"Tooltip text for user",2,false);
	}
	
	@AfterMethod
	public void gotoHomePage() throws Exception {
	//This method is to goto Home Page each time before executing a test
		Reporter.log("This method is to goto Home Page each time before executing a test.");
		businessFunctions.NavigateToPage("oLnk_Home","home");
	}
	
	/*@AfterClass
	public void logout() {
	//This method is to close Browser
		Reporter.log("This method is to close Browser");
		businessFunctions.Logout();
	}*/
}




