package commonUtilities;

public class globalVar {
	
	public static String tzStageUrl = "https://techzone-stage.cisco.com";
	public static String zblStageUrl = "https://zbl-stage.cisco.com:8443/zbl/gettingStarted.do";
	public static String rootFolder = "C:\\Selenium\\Eclipse_Workspace\\";
	public static String zblFilePath = rootFolder + "L3_Automation\\zblStage\\driverSheet.xlsx";
	public static String zblResultPath = rootFolder + "Results\\zblResults\\resultSheet.xlsx";
	public static String zblObjectRepoFolder = rootFolder + "L3_Automation\\zblObjectRepository\\";
	public static String zblResultSCfolder = rootFolder + "Results\\zblResults\\screenshot\\";
	public static String tzObjectRepoFolder = rootFolder + "L3_Automation\\tzObjectRepository\\";
	public static String tzFilePath = rootFolder + "L3_Automation\\tzStage\\driverSheet.xlsx";	
	public static String tzResultSCfolder = rootFolder + "Results\\tzResults\\screenshot\\";
	public static String tzResultPath = rootFolder + "Results\\tzResults\\resultSheet.xlsx";
	public static String tzTestImageURL = "https://www.customgrowthgroup.com/wp-content/uploads/2013/09/URL-image.jpg";
	public static String tzTestVideoURL = "https://www.youtube.com/watch?v=yeKGrOUZD-s";
	
}
