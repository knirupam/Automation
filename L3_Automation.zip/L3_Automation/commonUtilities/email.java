package commonUtilities;
import java.util.Properties;

import javax.mail.*;
import javax.mail.search.SubjectTerm;

public class email {
	
	public static Message getEmail(String emailID, String password, String subjectToBeSearched) throws Exception {
		Properties props = System.getProperties();
		props.setProperty("mail.store.protocol", "imaps");

		Session session = Session.getDefaultInstance(props, null);
		Store store = session.getStore("imaps");
		store.connect("imap.gmail.com", emailID, password);

		Folder folder = store.getFolder("INBOX");
		folder.open(Folder.READ_WRITE);

		Message[] messages = null;
		boolean mailFound = false;
		Message email = null;

		for (int i = 0; i < 30; i++) {
		    messages = folder.search(new SubjectTerm(subjectToBeSearched), folder.getMessages());
		    if (messages.length == 0) {
		        Thread.sleep(10000);
		    }
		}

		for (Message mail : messages) {
		    if (!mail.isSet(Flags.Flag.SEEN)) {
		        email = mail;
		        mailFound = true;
		    }
		}

		if (!mailFound) {
		    throw new Exception("Could not found Email");
		}

		return email;
		}

}
