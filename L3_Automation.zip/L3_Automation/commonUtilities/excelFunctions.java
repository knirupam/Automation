package commonUtilities;

	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import org.apache.poi.hssf.usermodel.HSSFWorkbook;
	import org.apache.poi.ss.usermodel.Cell;
	import org.apache.poi.ss.usermodel.CellType;
	import org.apache.poi.ss.usermodel.Row;
	import org.apache.poi.ss.usermodel.Sheet;
	import org.apache.poi.ss.usermodel.Workbook;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;


	public class excelFunctions {
		
		public File file;
		public FileInputStream inputStream;
		public FileOutputStream outputStream;
		public Workbook WB;
		public static Sheet WS;
		public static Row row;
		
		
		public excelFunctions(String strFile, String strSheet) throws IOException{
			file =    new File(strFile);
			inputStream = new FileInputStream(file);
		    WB = null;
		    String fileExtensionName = strFile.substring(strFile.indexOf("."));
		    if(fileExtensionName.equals(".xlsx")){
		    	WB = new XSSFWorkbook(inputStream);
		    }
	        else if(fileExtensionName.equals(".xls")){
	        	WB = new HSSFWorkbook(inputStream);
	        }
		    WS = WB.getSheetAt(0);
		}
		
		public String excelReadCell(int iRow, int iCol) throws IOException{
		    row = WS.getRow(iRow);
		    Cell cell = row.getCell(iCol);
		    if (cell!=null) {
		    	return cell.getStringCellValue();
		    }else return "";		    
		}
		
		public void excelWriteCell(int iRow, int iCol, String strVal, boolean hyperlink) throws IOException {
			row = WS.getRow(iRow);
			if (row==null) {
				row = WS.createRow(iRow);
			}
			Cell cell = row.createCell(iCol);
			if (hyperlink) {
				cell.setCellType(CellType.FORMULA);
				cell.setCellFormula("HYPERLINK(\""+strVal+"\")");				
			} else cell.setCellValue(strVal);					
			outputStream = new FileOutputStream(file);
			WB.write(outputStream);			
			outputStream.flush();
			outputStream.close();	
			inputStream.close();
		}
		
		public String excelSearchVal(String strVal) {
			int rowCount = WS.getLastRowNum()-WS.getFirstRowNum();		
			for(int i=0;i<rowCount;i++){
				row = WS.getRow(i);
				int colCount = row.getLastCellNum();
				for (int j=0;j<colCount;j++) {
					String strActual = row.getCell(j).getStringCellValue();
					if(strActual.equals(strVal)){
						return i+"/"+j;
					}
				}
			}
			return "Not Found";
		}
		
		public String excelGetColumnNames() {
			String colNames="";	
			row = WS.getRow(0);
			int colCount = row.getLastCellNum();
			for (int i=0;i<colCount;i++) {
				String strActual = row.getCell(i).getStringCellValue();
				colNames=colNames+";"+strActual;
			}
			return colNames;	
		}
		
	}
