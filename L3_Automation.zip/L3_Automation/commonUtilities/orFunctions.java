package commonUtilities;

import java.net.CookieStore;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.*;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.Augmenter;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;
import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.firefox.FirefoxDriver;

public class orFunctions {
	
	public static WebDriver driver;
	private FileInputStream stream;
	private String RepositoryFile;
	private List<WebElement> object = new ArrayList<WebElement>();
	public Map<Integer, Properties> propertyFiles = new HashMap<Integer, Properties>();
	//private Properties propertyFile = new Properties();
	public Map<String, List<WebElement>> object_map = new HashMap<String, List<WebElement>>();
 
	public orFunctions(String fileName) throws Exception{	
		for(int i=1;i<=fileName.split(";").length;i++) {
			this.RepositoryFile = fileName.split(";")[i-1];
			stream = new FileInputStream(RepositoryFile);
			Properties property = new Properties();
			property.load(stream);
			propertyFiles.put(i, property);
		}
		//this.RepositoryFile = fileName;
		//stream = new FileInputStream(RepositoryFile);
		//propertyFile.load(stream);
		//this.object_map = this.createWebElement(driver);	
	}
	
	@SuppressWarnings({ "deprecation", "unused" })
	public static void launchWithoutPingID(String Browser, String URL, String UserId, String Password) throws ClientProtocolException, IOException {
		{
            switch (Browser) {
            case "chrome" : driver = new ChromeDriver();
            break;
            case "firefox" : driver = new FirefoxDriver();
            break;
            }	
			final DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("https://sso-nprd.cisco.com/autho/apps/sso/getssosession/non-kerberos.html");
			httpPost.setHeader("userid",UserId);//mention user name
			httpPost.setHeader("password",Password);//mention password 
			HttpResponse response = httpClient.execute(httpPost);
			org.apache.http.client.CookieStore cookieStore = httpClient.getCookieStore();
			List<Cookie> cookies = httpClient.getCookieStore().getCookies();
			try {			
				driver.get(URL);			
				for (Cookie cookie : cookies)
				{
				    org.openqa.selenium.Cookie seleniumCookie = new org.openqa.selenium.Cookie(cookie.getName(), 
				    cookie.getValue());
				    driver.manage().addCookie(seleniumCookie);
				}
				driver.get(URL);
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
				driver.manage().window().maximize();			
			} catch(Exception e) {
			  e.printStackTrace();
			}
		}			
	}
	
	public static void launchApplication(String URL) {		
        driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.get(URL);
		driver.manage().window().maximize();
	}
 
	public By getobjectLocator(int index, String locatorName){		
		String locatorProperty = propertyFiles.get(index).getProperty(locatorName);
		//String locatorProperty = propertyFile.getProperty(locatorName);
		String arr[] = locatorProperty.split(":");
		String locatorType = arr[0].toLowerCase();
		String locatorValue=arr[1];
		for(int i=2;i<arr.length;i++) {
			locatorValue=locatorValue+":"+arr[i];
		}		 
		By locator = null;
		switch(locatorType)
		{
		case "id":
			locator = By.id(locatorValue);
			break;
		case "name":
			locator = By.name(locatorValue);
			break;
		case "cssselector":
			locator = By.cssSelector(locatorValue);
			break;
		case "linktext":
			locator = By.linkText(locatorValue);
			break;
		case "partiallinktext":
			locator = By.partialLinkText(locatorValue);
			break;
		case "tagName":
			locator = By.tagName(locatorValue);
			break;
		case "xpath":
			locator = By.xpath(locatorValue);
			break;
		}
		return locator;
	}
	
	public Map<String, List<WebElement>> createWebElement(int index) throws IOException{
		for (Enumeration<?> e = propertyFiles.get(index).propertyNames(); e.hasMoreElements();) {			
			object.clear();
			String keyName = e.nextElement().toString();
			object = driver.findElements(this.getobjectLocator(index, keyName));			
			object_map.put(keyName, object);
		}
		stream.close();
		return object_map;
	}
	
	public String captureScreen(String FolderPath) {
	    String path;
	    try {
	        WebDriver augmentedDriver = new Augmenter().augment(driver);
	        File source = ((TakesScreenshot)augmentedDriver).getScreenshotAs(OutputType.FILE);
	        path = FolderPath + source.getName();
	        //File screenShotName = new File(path);
	        FileUtils.copyFile(source, new File(path)); 
	    }
	    catch(IOException e) {
	        path = "Failed to capture screenshot: " + e.getMessage();
	    }
	    return path;
	}
	
	public static void logout() {		
		driver.quit();		
	}
	
	public static void handleAlert(String alertType) {
		switch(alertType) {
		case "warning" : driver.switchTo().alert().accept();
		break;
		case "image" : driver.switchTo().alert();
		break;
		default : driver.switchTo().alert().dismiss();
		}		
	}
	
	public static void switchToIframe(String frameId) throws InterruptedException {
		driver.switchTo().frame(frameId);
		for(int i=0;i<10;i++) {
			if (driver.findElement(By.tagName("body"))!=null) {
				break;
			}else Thread.sleep(2000);
		}
		driver.findElement(By.tagName("body")).click();
	}
	
	public static void switchToIframe(WebElement frame) throws InterruptedException {
		driver.switchTo().frame(frame);
		for(int i=0;i<10;i++) {
			if (driver.findElement(By.tagName("body"))!=null) {
				break;
			}else Thread.sleep(2000);
		}
		driver.findElement(By.tagName("body")).click();
	}
	
	public static int[] getRowsColsInTable(String XPath) {
		int RowCols[] = {0,0};
		RowCols[0] = driver.findElements(By.xpath(XPath+"//tbody/tr")).size();
		RowCols[1] = driver.findElements(By.xpath(XPath+"//th")).size();
		return RowCols;
	}
	
	public static String searchInTable(String XPath, String SearchText) {
		String addXpath = "";		
		for(int i=0;i<getRowsColsInTable(XPath)[0];i++) {
			for(int j=0;j<getRowsColsInTable(XPath)[1];j++) {
				addXpath = XPath+"//tr["+i+"]/td["+j+"]//*[contains(text(),'"+SearchText+"']";
				if(!(driver.findElement(By.xpath(addXpath))==null)) {
					return i+";"+j;
				}
			}
		}
		return null;
	}
	
	public static WebElement searchInTable(String TagName, int Row, int Col) {
		String Xpath = "//tr["+Row+"]/td["+Col+"]//"+TagName;
		return driver.findElement(By.xpath(Xpath));
	}
	
	public static String GetToolTipText(WebElement Object) {
		String Text="";
		String attribute = Object.getAttribute("aria-describedby");				
		int x = driver.findElements(By.xpath("//*[@id='"+attribute+"']//h4")).size();
		for(int i=0;i<x;i++) {
			Text = Text+driver.findElements(By.xpath("//*[@id='"+attribute+"']//h4")).get(i).getText();
		}
		Text=Text+";";
		x = driver.findElements(By.xpath("//*[@id='"+attribute+"']//p/font")).size();
		for(int i=0;i<x;i++) {
			Text = Text+driver.findElements(By.xpath("//*[@id='"+attribute+"']//p/font")).get(i).getText();
		}
		Text=Text+";";
		x = driver.findElements(By.xpath("//*[@id='"+attribute+"']//p")).size();
		for(int i=0;i<x;i++) {
			Text = Text+driver.findElements(By.xpath("//*[@id='"+attribute+"']//p")).get(i).getText();
		}
		Text=Text+";";
		x = driver.findElements(By.xpath("//*[@id='"+attribute+"']//b")).size();
		for(int i=0;i<x;i++) {
			Text = Text+driver.findElements(By.xpath("//*[@id='"+attribute+"']//b")).get(i).getText();
		}	
		return Text;
	}

}

