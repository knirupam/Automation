package commonUtilities;

public class logFunctions {

}
