package zblBusinessFunctions;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.WebElement;
import commonUtilities.*;

public class businessFunctions{
	
	public static excelFunctions iXL;
	public static excelFunctions oXL;
	public static orFunctions OR;
	
	public static Map<String, String> ReadInputRow(int iRow) throws IOException {
		iXL = new excelFunctions(globalVar.zblFilePath, "Sheet1");
		String cols = iXL.excelGetColumnNames();
		String[] colNames = cols.split(";");
		Map<String, String> InputData = new HashMap<String, String>();
		for(int i=0;i<colNames.length-1;i++) {
			InputData.put(colNames[i+1], iXL.excelReadCell(iRow, i));
		}
		return InputData;
	}
		
	public static void CreateORforPage(String strPropertiesFilePath) throws Exception {
		OR = new orFunctions(strPropertiesFilePath);		
	}
	
	public static void CompareStringAndWriteResult(String strExpected, String strActual, String strLog, int iRow, boolean screenshot) throws IOException {
		String[] resultlog = strLog.split("-");
		oXL = new excelFunctions(commonUtilities.globalVar.zblResultPath, "Sheet1");
		oXL.excelWriteCell(iRow, 0, resultlog[0], false);
		oXL.excelWriteCell(iRow, 1, resultlog[1], false);
		oXL.excelWriteCell(iRow, 2, strExpected, false);
		oXL.excelWriteCell(iRow, 3, strActual, false);
		if(screenshot) {
			String path = OR.captureScreen(globalVar.zblResultSCfolder);
			oXL.excelWriteCell(iRow, 5, path, true);
		}		
		if (strExpected.equals(strActual)){
			oXL.excelWriteCell(iRow, 4, "Pass", false);
		}else oXL.excelWriteCell(iRow, 4, "Fail", false);		
	}
	
	public static String LoginZBL(String strUserId,String strPwd) throws Exception{
		try {
			orFunctions.launchApplication(globalVar.zblStageUrl);
			CreateORforPage(globalVar.zblObjectRepoFolder+"ZBL_Login_OR.properties");
			OR.object_map.get("oEdt_UserID").get(0).sendKeys(strUserId);
			OR.object_map.get("oEdt_Pwd").get(0).sendKeys(strPwd);
			OR.object_map.get("oBtn_Login").get(0).click();
			if(OR.object_map.get("oLbl_ErrorLogin").isEmpty()) {
				return OR.object_map.get("oLbl_ErrorLogin").get(0).getText();					
			}else return "Successful Login";
		}catch(Exception e) {
			return "Unable to Login: "+e.toString();
		}
	}
	
	public static String HomePage_GetDisplayName() {
		return OR.object_map.get("oLbl_UserName").get(0).getText();
	}
	
	public static void HomePage_ValidateLinksDisplayed(int iRow) throws IOException {	
		String strActLinks = "";
		String strExpLinks = "oLnk_Redirect,oLnk_Admin,oLnk_OtherReports,oLnk_Research,oLnk_Create,oLnk_Search,oLnk_BulkRedirect,oLnk_Manage,oLnk_ImpactReport,oLnk_RedirectActivityReport,oLnk_KnownReferrerReport,oLnk_DownloadMalformURLReport";
		String[] arrExpLinks = strExpLinks.split(",");		
		for(int i=0;i<arrExpLinks.length;i++) {
			if(OR.object_map.get(arrExpLinks[i]).get(0).isDisplayed()) {
				strActLinks = strActLinks + arrExpLinks[i];
			}
		}	
		businessFunctions.CompareStringAndWriteResult(strExpLinks,strActLinks,"Home_Page_Links-All 12 links",iRow,false);
	}
		
	public static void HomePage_ValidateRedirectProgressReport(int iRow, String ExpReportHeading, String ColHeaders) throws IOException {
		String ActHeaders = "";
		//String ReportHeading = OR.object_map.get("oLbl_RedirectProgressHeader1").get(0).getText()+OR.object_map.get("oLbl_RedirectProgressHeader2").get(0).getText();
		//Business_Functions.CompareStringAndWriteResult(ExpReportHeading, ReportHeading, "Home_Page_RedirectProgressReport-Heading", iRow, false);
		for (int i=0; i<ColHeaders.split(";").length; i++){
			WebElement Header = OR.object_map.get("oTbl_RP_ColHeaders").get(i);
			if (Header==null) {
				break;
			}
			ActHeaders = ActHeaders+";"+Header.getText();
		}
		businessFunctions.CompareStringAndWriteResult(ColHeaders, ActHeaders.substring(1), "Home_Page_RedirectProgressReport-Heading", iRow, false);
	}

}

