package zblStage;

import java.util.Map;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import commonUtilities.*;
import zblBusinessFunctions.businessFunctions;

public class driverClassTest {
		
	//This is the driver class with all the tests. We can call business functions here to create a test.
	public static String strUserId; //User ID
	public static String strPwd; //Password
	public static String strMsg; //Message expected
	public static Map<String, String> Input; //This map is used to fetch values from a row in driver sheet (Column_Name:Value) 
	
	@BeforeClass
	private void Login() throws Exception {
	//This test is to test Login with correct User ID and password.
		Input = businessFunctions.ReadInputRow(1);
		strUserId = Input.get("UserId");
		strPwd = encryptionDecryption.decryptXOR(Input.get("EncodedPwd"),"1");
		strMsg = Input.get("Message");
		String strActualMsg = businessFunctions.LoginZBL(strUserId, strPwd);
		businessFunctions.CompareStringAndWriteResult(strMsg, strActualMsg, "Login_HappyPath-Login Test", 1, false);
	}
	
	@Test
	public void Test0() throws Exception {
	//This test is to create Web-elements for Home Page and will be a prerequisite for all the tests on home page
		businessFunctions.CreateORforPage(globalVar.zblObjectRepoFolder+"ZBL_Home_OR.properties");
	}
	
	@Test(dependsOnMethods={"Test0"})
	public void Test1() throws Exception{		
	//This test is to check that correct user name is displayed on home page after login
		String strDisplayName = businessFunctions.HomePage_GetDisplayName();	
		businessFunctions.CompareStringAndWriteResult(Input.get("DisplayName"), strDisplayName, "Display_Name-Correct User Test", 2, true);
	}
	
	@Test(dependsOnMethods={"Test0"})
	public void Test2() throws Exception {
	//This test is to check that all the links expected are present on the home page
		businessFunctions.HomePage_ValidateLinksDisplayed(3);
	}
	
	@Test(dependsOnMethods={"Test0"})
	public void Test3() throws Exception {
	//This test is to validate that there are correct row and column headers in redirect progress report
		Input = businessFunctions.ReadInputRow(2);
		businessFunctions.HomePage_ValidateRedirectProgressReport(4,Input.get("RedirectReportHeading"),Input.get("RedirectReportColHeaders"));
	}
	
	@AfterClass
	private void CloseBrowser() {
	//This is to close Browser at the end of test
		orFunctions.logout();
	}
	


}
